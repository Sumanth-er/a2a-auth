# A2A Auth Demo

Multi-agent system demonstrating end-to-end Keycloak JWT authentication flowing through remote A2A agents.

## Architecture

```
Browser (PKCE Login)
    │
    ▼
Keycloak ──── issues JWT ────────────────────────────────────────────────────┐
    │                                                                        │ JWKS
    ▼                                                                        │ (all agents validate here)
Frontend (port 3000)                                                         │
    │  POST /chat + Bearer token                                             │
    ▼                                                                        │
BFF (port 8000)  ── validate token ──────────────────────────────────────────┤
    │  A2AClient + Bearer token                                              │
    ▼                                                                        │
Orchestrator (port 8001)  ── validate token + role "user" ──────────────────┤
    │  Azure OpenAI decides routing                                          │
    ├── A2AClient + Bearer token ──▶ Weather Agent (8002) ── validate + role "weather"
    └── A2AClient + Bearer token ──▶ Data Analyst (8003) ── validate + role "analyst"
```

**Every node validates the token independently from Keycloak JWKS.**
The same token is forwarded at each hop — no new tokens are minted.

---

## Demo Users

| Username | Password | Roles | Can access |
|---|---|---|---|
| `admin_user` | `password` | user, weather, analyst | All agents |
| `weather_user` | `password` | user, weather | Weather only |
| `analyst_user` | `password` | user, analyst | Data Analyst only |
| `limited_user` | `password` | user | Neither agent (FORBIDDEN responses) |

---

## Quick Start

### 1. Prerequisites
- Docker + Docker Compose
- Azure OpenAI resource with a GPT-4o deployment

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env with your Azure OpenAI credentials
```

### 3. Start everything
```bash
docker compose up --build
```

Wait ~30 seconds for Keycloak to finish importing the realm.

### 4. Open the app
Navigate to **http://localhost:3000**

---

## How Auth Works (step by step)

### Login
1. User clicks **Login with Keycloak**
2. Browser redirects to Keycloak with PKCE challenge (`code_challenge_method=S256`)
3. User enters credentials
4. Keycloak redirects back with `?code=`
5. Frontend exchanges code + verifier for `access_token` + `refresh_token`
6. Token stored in `sessionStorage`

### Each Chat Message
```
Browser → BFF /chat
  Header: Authorization: Bearer <token>
  Body:   { message, refresh_token }

BFF:
  1. Validates token against Keycloak JWKS
  2. If token expiring < 60s: proactively refreshes via refresh_token
  3. Calls Orchestrator via A2AClient with Bearer token in httpx header

Orchestrator (A2A Server):
  1. TokenMiddleware captures Authorization header → current_token ContextVar
  2. OrchestratorExecutor reads token, validates it, checks role "user"
  3. Azure OpenAI decides which agents to route to
  4. Calls each agent via A2AClient with same Bearer token forwarded

Each Specialist Agent (A2A Server):
  1. TokenMiddleware captures token
  2. BaseAgentExecutor validates token + checks required_role
  3. If auth fails → returns "FORBIDDEN: Role 'X' required" via A2A event queue
  4. If auth passes → runs business logic (Azure OpenAI call)

Response flows back:
  Agent → Orchestrator → BFF → Browser
```

### Token Refresh (dual-layer)
- **Client-side**: `setTimeout` fires 60 s before expiry, calls BFF `/refresh`
- **Server-side**: BFF checks `exp` on every `/chat` call, refreshes if < 60 s remain
- **In-sync**: BFF returns `{ token_refreshed: true, access_token: "..." }` in chat response; browser updates sessionStorage

---

## Project Structure

```
a2a-auth-demo/
├── shared/
│   ├── auth.py              # JWT validation, JWKS cache, role checking, TokenMiddleware
│   └── config.py            # All env-var config
│
├── agents/
│   ├── base_agent.py        # Auth middleware base — ALL agents inherit this
│   ├── weather/
│   │   ├── agent.py         # WeatherAgentExecutor (required_role = "weather")
│   │   └── main.py          # A2A server on port 8002
│   └── data_analyst/
│       ├── agent.py         # DataAnalystAgentExecutor (required_role = "analyst")
│       └── main.py          # A2A server on port 8003
│
├── orchestrator/
│   ├── agent_registry.py   # ← ONLY file to edit when adding a new agent
│   ├── router.py            # Azure OpenAI routing logic
│   ├── agent.py             # OrchestratorExecutor with token forwarding
│   └── main.py              # A2A server on port 8001
│
├── bff/
│   └── main.py              # FastAPI: /chat, /refresh, /me, /health
│
├── frontend/
│   └── index.html           # JS chatbot with PKCE login, auto-refresh
│
├── keycloak/
│   └── realm-export.json    # Auto-imported on container start
│
├── Dockerfile.python
├── docker-compose.yml
├── requirements.txt
└── .env.example
```

---

## Adding a New Agent (3 steps)

### Step 1 — Create the agent executor
```python
# agents/my_agent/agent.py
from agents.base_agent import BaseAgentExecutor
from a2a.server.events import EventQueue
from a2a.utils import new_agent_text_artifact

class MyAgentExecutor(BaseAgentExecutor):
    required_role = "my_role"    # Keycloak role required
    agent_name    = "MyAgent"

    async def execute_verified(self, query: str, claims: dict, event_queue: EventQueue):
        # Auth already validated — just implement business logic
        answer = f"My agent response to: {query}"
        await event_queue.enqueue_event(new_agent_text_artifact(answer))
```

### Step 2 — Create the A2A server entrypoint
```python
# agents/my_agent/main.py
import uvicorn
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCapabilities, AgentCard, AgentSkill
from agents.my_agent.agent import MyAgentExecutor
from shared.auth import TokenMiddleware

def build_app():
    agent_card = AgentCard(
        name="My Agent",
        description="Does my thing.",
        url="http://my-agent:8004/",
        version="1.0.0",
        capabilities=AgentCapabilities(streaming=False),
        skills=[AgentSkill(id="my_skill", name="My Skill",
                           description="...", tags=["my_tag"])],
    )
    handler = DefaultRequestHandler(
        agent_executor=MyAgentExecutor(),
        task_store=InMemoryTaskStore(),
    )
    app = A2AStarletteApplication(agent_card=agent_card, http_handler=handler)
    return TokenMiddleware(app.build())

if __name__ == "__main__":
    uvicorn.run(build_app(), host="0.0.0.0", port=8004)
```

### Step 3 — Register in the registry
```python
# orchestrator/agent_registry.py — add one entry:
"my_agent": {
    "url": "http://my-agent:8004",
    "description": "Does my thing when users ask about X.",
    "role_hint": "my_role",
},
```

Then add to `docker-compose.yml`:
```yaml
my-agent:
  <<: *python-base
  command: python -m agents.my_agent.main
  ports:
    - "8004:8004"
```

Add role `my_role` in Keycloak and assign it to relevant users. **That's it.**

---

## Token Forwarding in A2A

The A2A SDK's `A2AClient` uses an `httpx.AsyncClient` under the hood.
We inject the Bearer token as a default header on that client:

```python
async with httpx.AsyncClient(headers={"Authorization": f"Bearer {token}"}) as http_client:
    a2a_client = await A2AClient.get_client_from_agent_card_url(
        httpx_client=http_client,
        base_url=agent_url,
    )
    response = await a2a_client.send_message(request)
```

The downstream agent's `TokenMiddleware` (pure ASGI) reads this header
from the HTTP scope before the A2A handler runs, writing it to a
`ContextVar`. The `BaseAgentExecutor` then reads from that ContextVar —
no changes to the A2A message schema are needed.

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| FORBIDDEN on all agents | User missing role | Assign role in Keycloak → Users → Role Mappings |
| UNAUTHORIZED on every request | Token expired | Check token refresh timer; ensure `/refresh` endpoint reachable |
| Orchestrator returns "No agent" | Router hallucinated | Query is too vague; rephrase; check Azure OpenAI deployment name |
| Keycloak 404 on startup | Realm not imported | Check `keycloak/realm-export.json` is mounted; wait for healthcheck |
| CORS error on `/chat` | BFF not running | Check BFF container logs; verify port 8000 is exposed |
