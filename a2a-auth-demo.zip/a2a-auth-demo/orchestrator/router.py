"""
orchestrator/router.py
───────────────────────
Uses Azure OpenAI to decide which agent(s) from the registry
should handle a given user query.

The agent descriptions in AGENT_REGISTRY are fed to the model dynamically,
so adding a new agent to the registry automatically makes the router aware of it.
"""

import json
import logging
from openai import AzureOpenAI

from orchestrator.agent_registry import AGENT_REGISTRY
from shared.config import (
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_DEPLOYMENT,
    AZURE_OPENAI_API_VERSION,
)

logger = logging.getLogger(__name__)

_llm = AzureOpenAI(
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
    api_version=AZURE_OPENAI_API_VERSION,
)

_ROUTER_SYSTEM = """You are a routing assistant for a multi-agent system.
Given a user query, decide which agent(s) should handle it.
Respond with ONLY a valid JSON array of agent keys from the available agents.
Example responses: ["weather"] or ["data_analyst"] or ["weather","data_analyst"]
If no agent is appropriate, return [].
Do not include any other text."""


def route_query(user_query: str) -> list[str]:
    """
    Returns a list of agent keys (from AGENT_REGISTRY) that should handle
    the user's query. May return multiple keys if the query spans agents.
    """
    agent_list = "\n".join(
        f'  "{key}": {cfg["description"]}'
        for key, cfg in AGENT_REGISTRY.items()
    )
    user_prompt = (
        f"Available agents:\n{agent_list}\n\n"
        f'User query: "{user_query}"\n\n'
        f"Which agent key(s) should handle this? Respond with a JSON array only."
    )

    try:
        response = _llm.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT,
            messages=[
                {"role": "system", "content": _ROUTER_SYSTEM},
                {"role": "user",   "content": user_prompt},
            ],
            max_tokens=64,
            temperature=0,
        )
        raw = response.choices[0].message.content.strip()
        keys: list[str] = json.loads(raw)
        # Filter out any hallucinated keys
        valid = [k for k in keys if k in AGENT_REGISTRY]
        logger.info("Router: query=%r → agents=%s", user_query[:60], valid)
        return valid
    except Exception as exc:
        logger.error("Router error: %s — defaulting to no agents", exc)
        return []
