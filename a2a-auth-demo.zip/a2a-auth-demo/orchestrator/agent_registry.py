"""
orchestrator/agent_registry.py
────────────────────────────────
THE ONLY FILE YOU CHANGE when adding a new downstream A2A agent.

Each entry describes:
  url         — where the A2A server lives (used by A2AClient for discovery)
  description — shown to Azure OpenAI for routing decisions
  role_hint   — the Keycloak role needed (informational; actual enforcement
                is done by the agent itself)
"""

from shared.config import WEATHER_AGENT_URL, DATA_AGENT_URL

# ── Registry ──────────────────────────────────────────────────────────────────
AGENT_REGISTRY: dict[str, dict] = {
    "weather": {
        "url": WEATHER_AGENT_URL,
        "description": (
            "Answers questions about weather conditions, forecasts, climate, "
            "temperature, rainfall, humidity, and seasonal patterns for any location."
        ),
        "role_hint": "weather",
    },
    "data_analyst": {
        "url": DATA_AGENT_URL,
        "description": (
            "Performs data analysis, interprets statistics, explains analytical concepts, "
            "identifies trends in numbers, and generates insights from datasets."
        ),
        "role_hint": "analyst",
    },
    # ── To add a new agent ────────────────────────────────────────────────────
    # 1. Create agents/my_agent/agent.py  (inherit BaseAgentExecutor)
    # 2. Create agents/my_agent/main.py   (spin up A2A server)
    # 3. Add an entry here — the orchestrator picks it up automatically.
    # 4. Add the service to docker-compose.yml
    #
    # "my_agent": {
    #     "url": "http://my-agent:8004",
    #     "description": "What this agent does...",
    #     "role_hint": "my_role",
    # },
}
