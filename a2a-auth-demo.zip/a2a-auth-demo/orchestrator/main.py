"""
orchestrator/main.py
─────────────────────
Starts the Orchestrator as a standalone A2A server.
Same pattern as specialist agents: build() + TokenMiddleware.
"""

import logging
import uvicorn

from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCapabilities, AgentCard, AgentSkill

from orchestrator.agent import OrchestratorExecutor
from shared.auth import TokenMiddleware

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

PORT = 8001
HOST = "0.0.0.0"
PUBLIC_URL = f"http://orchestrator:{PORT}"


def build_app():
    agent_card = AgentCard(
        name="Orchestrator",
        description=(
            "Multi-agent orchestrator. Routes queries to specialist agents "
            "(weather, data analyst, etc.) and returns combined results."
        ),
        url=f"{PUBLIC_URL}/",
        version="1.0.0",
        capabilities=AgentCapabilities(streaming=False),
        skills=[
            AgentSkill(
                id="orchestrate",
                name="Orchestrate",
                description="Route user queries to the correct specialist agent(s)",
                tags=["orchestration", "routing"],
                examples=[
                    "What is the weather in Paris?",
                    "Analyse these numbers: 10, 20, 30, 25, 15",
                ],
            )
        ],
    )

    handler = DefaultRequestHandler(
        agent_executor=OrchestratorExecutor(),
        task_store=InMemoryTaskStore(),
    )

    a2a_app = A2AStarletteApplication(
        agent_card=agent_card,
        http_handler=handler,
    )

    return TokenMiddleware(a2a_app.build())


if __name__ == "__main__":
    logger.info("Starting Orchestrator on %s:%d", HOST, PORT)
    uvicorn.run(build_app(), host=HOST, port=PORT)
