"""
orchestrator/agent.py
──────────────────────
The orchestrator is itself an A2A agent (server) that:

  1. Validates the incoming token (must have role "user").
  2. Calls Azure OpenAI to decide which downstream agents to invoke.
  3. For each target agent, creates an A2AClient with the SAME token
     forwarded in the Authorization header (token propagation).
  4. Collects results — including auth errors returned by downstream agents.
  5. Returns a combined answer.

Token forwarding strategy
─────────────────────────
We pass the original Bearer token as an HTTP header to each A2A agent:

    httpx.AsyncClient(headers={"Authorization": f"Bearer {token}"})
    A2AClient(httpx_client=http_client, agent_card=card)

The downstream agent's TokenMiddleware captures this header and injects
it into current_token ContextVar before BaseAgentExecutor.execute() runs.
No changes to the A2A message protocol are needed.
"""

import asyncio
import logging
import uuid

import httpx
from a2a.client import A2AClient
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.types import (
    Message, MessageSendParams, Part, Role,
    SendMessageRequest, TextPart,
)
from a2a.utils import new_agent_text_artifact

from orchestrator.agent_registry import AGENT_REGISTRY
from orchestrator.router import route_query
from shared.auth import current_token, validate_token, require_role, AuthError

logger = logging.getLogger(__name__)


class OrchestratorExecutor(AgentExecutor):
    """Routes messages to downstream A2A agents with token propagation."""

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        token = current_token.get()

        # ── 1. Validate orchestrator-level auth ───────────────────────────────
        if not token:
            await event_queue.enqueue_event(
                new_agent_text_artifact("UNAUTHORIZED: No auth token provided.")
            )
            return

        try:
            claims = await validate_token(token)
            require_role(claims, "user")   # minimum role every user must have
        except AuthError as exc:
            await event_queue.enqueue_event(
                new_agent_text_artifact(
                    f"{'UNAUTHORIZED' if exc.status_code == 401 else 'FORBIDDEN'}: {exc.detail}"
                )
            )
            return

        query = context.get_user_input()
        username = claims.get("preferred_username", "?")
        logger.info("[Orchestrator] User '%s' query: %r", username, query[:80])

        # ── 2. Route: which agents should handle this? ────────────────────────
        target_keys = route_query(query)

        if not target_keys:
            await event_queue.enqueue_event(
                new_agent_text_artifact(
                    "I couldn't determine which agent should handle your request. "
                    "Please try rephrasing your question."
                )
            )
            return

        # ── 3. Call each target agent in parallel ─────────────────────────────
        tasks = [
            _call_remote_agent(key, query, token)
            for key in target_keys
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # ── 4. Assemble final response ────────────────────────────────────────
        parts = []
        for key, result in zip(target_keys, results):
            if isinstance(result, Exception):
                parts.append(f"**[{key.upper()}]** Error: {result}")
            else:
                parts.append(f"**[{key.upper()}]**\n{result}")

        final = "\n\n---\n\n".join(parts)
        await event_queue.enqueue_event(new_agent_text_artifact(final))

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        await event_queue.enqueue_event(
            new_agent_text_artifact("Cancellation is not supported.")
        )


async def _call_remote_agent(agent_key: str, query: str, token: str) -> str:
    """
    Call a single downstream A2A agent using A2AClient.

    The token is forwarded as an HTTP Authorization header on the httpx client,
    which is then used for ALL requests made by A2AClient (including agent card
    discovery and the actual message send).
    """
    cfg = AGENT_REGISTRY[agent_key]
    base_url: str = cfg["url"]

    logger.info("[Orchestrator] Calling agent '%s' at %s", agent_key, base_url)

    # Create httpx client with the forwarded token
    headers = {"Authorization": f"Bearer {token}"}

    async with httpx.AsyncClient(headers=headers, timeout=30.0) as http_client:
        try:
            # Discover agent via its agent card (GET /.well-known/agent.json)
            a2a_client = await A2AClient.get_client_from_agent_card_url(
                httpx_client=http_client,
                base_url=base_url,
            )

            # Build A2A message
            request = SendMessageRequest(
                id=str(uuid.uuid4()),
                params=MessageSendParams(
                    message=Message(
                        role=Role.user,
                        parts=[Part(root=TextPart(text=query))],
                    )
                ),
            )

            response = await a2a_client.send_message(request)
            return _extract_text(response)

        except Exception as exc:
            logger.error("[Orchestrator] Failed to call agent '%s': %s", agent_key, exc)
            raise


def _extract_text(response) -> str:
    """
    Robustly extract text from an A2A SendMessageResponse.
    Handles both artifact-based and status-message-based responses.
    """
    try:
        root = response.root

        # ── Try artifacts first (new_agent_text_artifact creates these) ───────
        artifacts = getattr(root, "artifacts", None) or []
        texts = []
        for artifact in artifacts:
            for part in getattr(artifact, "parts", []):
                p = getattr(part, "root", part)
                if hasattr(p, "text") and p.text:
                    texts.append(p.text)
        if texts:
            return "\n".join(texts)

        # ── Fall back to status.message ───────────────────────────────────────
        status = getattr(root, "status", None)
        if status:
            msg = getattr(status, "message", None)
            if msg:
                for part in getattr(msg, "parts", []):
                    p = getattr(part, "root", part)
                    if hasattr(p, "text") and p.text:
                        texts.append(p.text)
        if texts:
            return "\n".join(texts)

    except Exception as exc:
        logger.warning("Text extraction error: %s", exc)

    return str(response)
