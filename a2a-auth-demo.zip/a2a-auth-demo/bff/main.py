"""
bff/main.py
────────────
Backend for Frontend — the only service the browser talks to directly.

Endpoints:
  POST /chat              — validate token, (maybe refresh), call Orchestrator
  POST /refresh           — explicit token refresh
  GET  /me                — return decoded claims for the UI to display
  GET  /health            — liveness probe

Token refresh strategy (dual-layer):
  Client-side: JS schedules a refresh 60 s before expiry.
  Server-side: BFF also checks expiry on every /chat call.
  If BFF refreshes, it returns the new token so the browser stores it.
  Both layers stay in sync through the chat response payload.
"""

import logging
import time
import uuid
from typing import Optional

import httpx
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from jose import jwt as jose_jwt
from pydantic import BaseModel

from a2a.client import A2AClient
from a2a.types import (
    Message, MessageSendParams, Part, Role,
    SendMessageRequest, TextPart,
)

from shared.auth import validate_token, AuthError, extract_bearer
from shared.config import (
    BFF_PORT,
    KEYCLOAK_TOKEN_URL,
    KEYCLOAK_CLIENT_ID,
    ORCHESTRATOR_URL,
    TOKEN_REFRESH_BUFFER,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="A2A Auth Demo — BFF", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # tighten to your frontend origin in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Request / response models ─────────────────────────────────────────────────
class ChatRequest(BaseModel):
    message: str
    refresh_token: Optional[str] = None   # Browser passes this for server-side refresh


class ChatResponse(BaseModel):
    reply: str
    access_token: str    # Always returned — may be refreshed
    token_refreshed: bool = False


class RefreshRequest(BaseModel):
    refresh_token: str


# ── Helpers ───────────────────────────────────────────────────────────────────
def _decode_exp(token: str) -> float:
    """Decode exp claim without signature verification (we just need timing)."""
    try:
        payload = jose_jwt.decode(token, options={"verify_signature": False})
        return float(payload.get("exp", 0))
    except Exception:
        return 0.0


async def _keycloak_refresh(refresh_token: str) -> dict:
    """Exchange a refresh_token for a new token set from Keycloak."""
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            KEYCLOAK_TOKEN_URL,
            data={
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "client_id": KEYCLOAK_CLIENT_ID,
            },
            timeout=10,
        )
        if resp.status_code != 200:
            raise HTTPException(401, f"Token refresh failed: {resp.text}")
        return resp.json()


async def _maybe_refresh(
    access_token: str, refresh_token: Optional[str]
) -> tuple[str, bool]:
    """
    Returns (token_to_use, was_refreshed).
    If the access token expires within TOKEN_REFRESH_BUFFER seconds AND
    a refresh_token was supplied, proactively fetch new tokens.
    """
    exp = _decode_exp(access_token)
    remaining = exp - time.time()

    if remaining < TOKEN_REFRESH_BUFFER and refresh_token:
        logger.info("BFF: proactive token refresh (%.0f s remaining)", remaining)
        new_tokens = await _keycloak_refresh(refresh_token)
        return new_tokens["access_token"], True

    return access_token, False


def _extract_reply(response) -> str:
    """Extract text from A2A SendMessageResponse."""
    try:
        root = response.root
        artifacts = getattr(root, "artifacts", None) or []
        texts = []
        for artifact in artifacts:
            for part in getattr(artifact, "parts", []):
                p = getattr(part, "root", part)
                if hasattr(p, "text") and p.text:
                    texts.append(p.text)
        if texts:
            return "\n".join(texts)

        status = getattr(root, "status", None)
        if status:
            msg = getattr(status, "message", None)
            if msg:
                for part in getattr(msg, "parts", []):
                    p = getattr(part, "root", part)
                    if hasattr(p, "text") and p.text:
                        texts.append(p.text)
        if texts:
            return "\n".join(texts)
    except Exception as exc:
        logger.warning("BFF: response extraction error: %s", exc)

    return str(response)


# ── Routes ────────────────────────────────────────────────────────────────────
@app.post("/chat", response_model=ChatResponse)
async def chat(body: ChatRequest, request: Request):
    # 1. Extract + validate token from Authorization header
    auth_header = request.headers.get("Authorization", "")
    access_token = extract_bearer(auth_header)
    if not access_token:
        raise HTTPException(401, "Authorization header missing or malformed")

    try:
        await validate_token(access_token)
    except AuthError as exc:
        # If expired and refresh token provided, try to refresh first
        if exc.status_code == 401 and body.refresh_token:
            logger.info("BFF: access token invalid, attempting refresh")
            try:
                new_tokens = await _keycloak_refresh(body.refresh_token)
                access_token = new_tokens["access_token"]
                await validate_token(access_token)   # Validate the fresh token
                token_was_refreshed = True
            except Exception as refresh_exc:
                raise HTTPException(401, f"Auth failed and refresh failed: {refresh_exc}")
        else:
            raise HTTPException(exc.status_code, exc.detail)
    else:
        # Token valid — maybe proactively refresh if near expiry
        access_token, token_was_refreshed = await _maybe_refresh(
            access_token, body.refresh_token
        )

    # 2. Forward to Orchestrator via A2AClient with token in header
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        async with httpx.AsyncClient(headers=headers, timeout=60.0) as http_client:
            a2a_client = await A2AClient.get_client_from_agent_card_url(
                httpx_client=http_client,
                base_url=ORCHESTRATOR_URL,
            )
            send_request = SendMessageRequest(
                id=str(uuid.uuid4()),
                params=MessageSendParams(
                    message=Message(
                        role=Role.user,
                        parts=[Part(root=TextPart(text=body.message))],
                    )
                ),
            )
            response = await a2a_client.send_message(send_request)
            reply = _extract_reply(response)

    except Exception as exc:
        logger.error("BFF: orchestrator call failed: %s", exc)
        raise HTTPException(502, f"Orchestrator unavailable: {exc}")

    return ChatResponse(
        reply=reply,
        access_token=access_token,
        token_refreshed=token_was_refreshed,
    )


@app.post("/refresh")
async def refresh_token(body: RefreshRequest):
    """Explicit token refresh endpoint (called by frontend timer)."""
    try:
        new_tokens = await _keycloak_refresh(body.refresh_token)
        return {
            "access_token": new_tokens["access_token"],
            "refresh_token": new_tokens.get("refresh_token", body.refresh_token),
            "expires_in": new_tokens.get("expires_in", 300),
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, f"Refresh failed: {exc}")


@app.get("/me")
async def me(request: Request):
    """Returns decoded claims for display in the UI."""
    auth_header = request.headers.get("Authorization", "")
    token = extract_bearer(auth_header)
    if not token:
        raise HTTPException(401, "No token")
    try:
        claims = await validate_token(token)
        return {
            "sub": claims.get("sub"),
            "username": claims.get("preferred_username"),
            "email": claims.get("email"),
            "roles": claims.get("realm_access", {}).get("roles", []),
            "exp": claims.get("exp"),
        }
    except AuthError as exc:
        raise HTTPException(exc.status_code, exc.detail)


@app.get("/health")
async def health():
    return {"status": "ok"}


if __name__ == "__main__":
    uvicorn.run("bff.main:app", host="0.0.0.0", port=BFF_PORT, reload=False)
