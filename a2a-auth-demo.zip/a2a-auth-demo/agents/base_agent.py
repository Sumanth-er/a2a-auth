"""
agents/base_agent.py
────────────────────
BaseAgentExecutor — inherit this for EVERY specialist agent.

What it does automatically:
  1. Reads the token placed in current_token ContextVar by TokenMiddleware.
  2. Validates the token against Keycloak JWKS.
  3. Checks that the caller has the agent's required_role.
  4. If auth passes, delegates to execute_verified() with the verified claims.
  5. If auth fails, returns a structured UNAUTHORIZED/FORBIDDEN message
     back through the A2A event queue so the orchestrator can surface it.

Adding a new agent:
  - Subclass BaseAgentExecutor
  - Set  required_role = "my_role"
  - Implement  async execute_verified(query, claims, event_queue)
  - Done — no auth boilerplate needed.
"""

import logging
from abc import abstractmethod

from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.utils import new_agent_text_artifact

from shared.auth import current_token, validate_token, require_role, AuthError

logger = logging.getLogger(__name__)


class BaseAgentExecutor(AgentExecutor):
    """Auth-aware base executor. All specialist agents inherit this."""

    # ── Override in subclass ──────────────────────────────────────────────────
    required_role: str = ""   # e.g. "weather", "analyst"
    agent_name: str = "Agent" # Used in log messages

    # ── A2A protocol methods ──────────────────────────────────────────────────
    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        token = current_token.get()

        # ── Step 1: token present? ────────────────────────────────────────────
        if not token:
            logger.warning("[%s] Request with no auth token", self.agent_name)
            await _send_error(event_queue, 401, "UNAUTHORIZED: No auth token in request.")
            return

        # ── Step 2: validate signature + expiry ───────────────────────────────
        try:
            claims = await validate_token(token)
        except AuthError as exc:
            logger.warning("[%s] Token validation failed: %s", self.agent_name, exc)
            await _send_error(event_queue, exc.status_code, f"UNAUTHORIZED: {exc.detail}")
            return

        # ── Step 3: role check ────────────────────────────────────────────────
        if self.required_role:
            try:
                require_role(claims, self.required_role)
            except AuthError as exc:
                logger.warning(
                    "[%s] Role check failed for user '%s': %s",
                    self.agent_name,
                    claims.get("preferred_username", "?"),
                    exc,
                )
                await _send_error(event_queue, exc.status_code, f"FORBIDDEN: {exc.detail}")
                return

        # ── Step 4: auth passed — run business logic ──────────────────────────
        query = context.get_user_input()
        logger.info(
            "[%s] Authenticated request from '%s' (roles=%s): %r",
            self.agent_name,
            claims.get("preferred_username", "?"),
            claims.get("realm_access", {}).get("roles", []),
            query[:80],
        )
        await self.execute_verified(query=query, claims=claims, event_queue=event_queue)

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        await _send_error(event_queue, 400, "Cancellation is not supported by this agent.")

    # ── Subclasses implement this ─────────────────────────────────────────────
    @abstractmethod
    async def execute_verified(
        self, query: str, claims: dict, event_queue: EventQueue
    ) -> None:
        """
        Called only after auth has passed.
        `claims` contains the verified JWT payload (sub, preferred_username,
        realm_access.roles, etc.)
        """


# ── Helper ────────────────────────────────────────────────────────────────────
async def _send_error(event_queue: EventQueue, status_code: int, message: str) -> None:
    """Send a structured error response through the A2A event queue."""
    prefix = "UNAUTHORIZED" if status_code == 401 else "FORBIDDEN"
    # Normalise so the orchestrator can parse auth errors reliably
    text = message if message.startswith((prefix, "UNAUTHORIZED", "FORBIDDEN")) else f"{prefix}: {message}"
    await event_queue.enqueue_event(new_agent_text_artifact(text))
