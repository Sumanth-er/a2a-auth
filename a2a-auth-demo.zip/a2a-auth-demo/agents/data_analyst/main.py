"""
agents/data_analyst/main.py
────────────────────────────
Starts the Data Analyst Agent as a standalone A2A server.
"""

import logging
import uvicorn

from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCapabilities, AgentCard, AgentSkill

from agents.data_analyst.agent import DataAnalystAgentExecutor
from shared.auth import TokenMiddleware

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

PORT = 8003
HOST = "0.0.0.0"
PUBLIC_URL = f"http://data-analyst-agent:{PORT}"


def build_app():
    agent_card = AgentCard(
        name="Data Analyst Agent",
        description=(
            "Performs data analysis, statistics, and generates insights. "
            "Requires Keycloak role: 'analyst'."
        ),
        url=f"{PUBLIC_URL}/",
        version="1.0.0",
        capabilities=AgentCapabilities(streaming=False),
        skills=[
            AgentSkill(
                id="data_analysis",
                name="Data Analysis",
                description="Analyse data and generate statistical insights",
                tags=["data", "analysis", "statistics", "insights"],
                examples=[
                    "Analyse this sales data: [100, 150, 120, 200, 180]",
                    "What are common causes of data skewness?",
                    "Explain the difference between mean and median.",
                ],
            )
        ],
    )

    handler = DefaultRequestHandler(
        agent_executor=DataAnalystAgentExecutor(),
        task_store=InMemoryTaskStore(),
    )

    a2a_app = A2AStarletteApplication(
        agent_card=agent_card,
        http_handler=handler,
    )

    return TokenMiddleware(a2a_app.build())


if __name__ == "__main__":
    logger.info("Starting Data Analyst Agent on %s:%d", HOST, PORT)
    uvicorn.run(build_app(), host=HOST, port=PORT)
