"""
agents/data_analyst/agent.py
─────────────────────────────
Specialist agent: performs data analysis and generates insights.
Required Keycloak role: "analyst"
"""

import logging
from openai import AzureOpenAI

from a2a.server.events import EventQueue
from a2a.utils import new_agent_text_artifact

from agents.base_agent import BaseAgentExecutor
from shared.config import (
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_DEPLOYMENT,
    AZURE_OPENAI_API_VERSION,
)

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """You are an expert data analyst.
Help users understand data, statistics, trends, and analytical concepts.
Provide clear explanations with examples where helpful.
If given data in the query, analyse it and return insights.
Be concise and precise."""


class DataAnalystAgentExecutor(BaseAgentExecutor):
    required_role = "analyst"
    agent_name    = "DataAnalystAgent"

    def __init__(self):
        self._llm = AzureOpenAI(
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
        )

    async def execute_verified(
        self, query: str, claims: dict, event_queue: EventQueue
    ) -> None:
        username = claims.get("preferred_username", "user")
        logger.info("[DataAnalystAgent] Processing query from %s: %r", username, query)

        try:
            response = self._llm.chat.completions.create(
                model=AZURE_OPENAI_DEPLOYMENT,
                messages=[
                    {"role": "system", "content": _SYSTEM_PROMPT},
                    {"role": "user",   "content": query},
                ],
                max_tokens=768,
                temperature=0.3,
            )
            answer = response.choices[0].message.content.strip()
        except Exception as exc:
            logger.error("[DataAnalystAgent] LLM error: %s", exc)
            answer = f"Data analyst agent encountered an error: {exc}"

        await event_queue.enqueue_event(new_agent_text_artifact(answer))
