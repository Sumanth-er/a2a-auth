"""
agents/weather/main.py
───────────────────────
Starts the Weather Agent as a standalone A2A server.

The A2AStarletteApplication is built, then wrapped with TokenMiddleware
so every incoming HTTP request has its Authorization header extracted
into the `current_token` ContextVar before the executor runs.
"""

import logging
import uvicorn

from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCapabilities, AgentCard, AgentSkill

from agents.weather.agent import WeatherAgentExecutor
from shared.auth import TokenMiddleware

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

PORT = 8002
HOST = "0.0.0.0"
PUBLIC_URL = f"http://weather-agent:{PORT}"  # As seen by other containers


def build_app():
    agent_card = AgentCard(
        name="Weather Agent",
        description=(
            "Answers questions about weather, climate, and forecasts. "
            "Requires Keycloak role: 'weather'."
        ),
        url=f"{PUBLIC_URL}/",
        version="1.0.0",
        capabilities=AgentCapabilities(streaming=False),
        skills=[
            AgentSkill(
                id="weather_query",
                name="Weather Query",
                description="Answer weather and climate questions",
                tags=["weather", "climate", "forecast"],
                examples=[
                    "What is the weather like in London in December?",
                    "Is it monsoon season in Mumbai right now?",
                ],
            )
        ],
    )

    handler = DefaultRequestHandler(
        agent_executor=WeatherAgentExecutor(),
        task_store=InMemoryTaskStore(),
    )

    a2a_app = A2AStarletteApplication(
        agent_card=agent_card,
        http_handler=handler,
    )

    # Wrap the ASGI app with our auth-token-capture middleware.
    # TokenMiddleware reads Authorization header → current_token ContextVar.
    return TokenMiddleware(a2a_app.build())


if __name__ == "__main__":
    logger.info("Starting Weather Agent on %s:%d", HOST, PORT)
    uvicorn.run(build_app(), host=HOST, port=PORT)
