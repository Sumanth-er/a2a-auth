"""
agents/weather/agent.py
────────────────────────
Specialist agent: answers weather questions.
Required Keycloak role: "weather"

This class only contains business logic — all auth is handled
by BaseAgentExecutor before execute_verified() is ever called.
"""

import logging
from openai import AzureOpenAI

from a2a.server.events import EventQueue
from a2a.utils import new_agent_text_artifact

from agents.base_agent import BaseAgentExecutor
from shared.config import (
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_DEPLOYMENT,
    AZURE_OPENAI_API_VERSION,
)

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """You are a helpful weather assistant.
Answer questions about weather, climate, forecasts, and related topics.
Be concise and informative. If asked about real-time data you don't have,
explain what the weather is typically like in that location/season."""


class WeatherAgentExecutor(BaseAgentExecutor):
    required_role = "weather"
    agent_name    = "WeatherAgent"

    def __init__(self):
        self._llm = AzureOpenAI(
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
        )

    async def execute_verified(
        self, query: str, claims: dict, event_queue: EventQueue
    ) -> None:
        username = claims.get("preferred_username", "user")
        logger.info("[WeatherAgent] Processing query from %s: %r", username, query)

        try:
            response = self._llm.chat.completions.create(
                model=AZURE_OPENAI_DEPLOYMENT,
                messages=[
                    {"role": "system", "content": _SYSTEM_PROMPT},
                    {"role": "user",   "content": query},
                ],
                max_tokens=512,
                temperature=0.7,
            )
            answer = response.choices[0].message.content.strip()
        except Exception as exc:
            logger.error("[WeatherAgent] LLM error: %s", exc)
            answer = f"Weather agent encountered an error: {exc}"

        await event_queue.enqueue_event(new_agent_text_artifact(answer))
