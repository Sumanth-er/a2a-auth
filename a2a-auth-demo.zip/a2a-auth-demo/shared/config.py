import os
from dotenv import load_dotenv

load_dotenv()

# ── Keycloak ──────────────────────────────────────────────────────────────────
KEYCLOAK_URL        = os.getenv("KEYCLOAK_URL", "http://keycloak:8080")
KEYCLOAK_REALM      = os.getenv("KEYCLOAK_REALM", "a2a-demo")
KEYCLOAK_CLIENT_ID  = os.getenv("KEYCLOAK_CLIENT_ID", "a2a-public")

KEYCLOAK_ISSUER  = f"{KEYCLOAK_URL}/realms/{KEYCLOAK_REALM}"
KEYCLOAK_JWKS_URL = f"{KEYCLOAK_ISSUER}/protocol/openid-connect/certs"
KEYCLOAK_TOKEN_URL = f"{KEYCLOAK_ISSUER}/protocol/openid-connect/token"

# ── Azure OpenAI ──────────────────────────────────────────────────────────────
AZURE_OPENAI_ENDPOINT   = os.getenv("AZURE_OPENAI_ENDPOINT", "")
AZURE_OPENAI_API_KEY    = os.getenv("AZURE_OPENAI_API_KEY", "")
AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview")

# ── Service URLs ──────────────────────────────────────────────────────────────
ORCHESTRATOR_URL    = os.getenv("ORCHESTRATOR_URL",    "http://orchestrator:8001")
WEATHER_AGENT_URL   = os.getenv("WEATHER_AGENT_URL",   "http://weather-agent:8002")
DATA_AGENT_URL      = os.getenv("DATA_AGENT_URL",      "http://data-analyst-agent:8003")

# ── BFF ───────────────────────────────────────────────────────────────────────
BFF_PORT = int(os.getenv("BFF_PORT", "8000"))

# ── Token refresh buffer (seconds before expiry to proactively refresh) ───────
TOKEN_REFRESH_BUFFER = int(os.getenv("TOKEN_REFRESH_BUFFER", "60"))
