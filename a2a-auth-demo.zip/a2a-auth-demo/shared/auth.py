"""
shared/auth.py
──────────────
Single source of truth for ALL token validation across the system.
Used by: BFF, Orchestrator, and every downstream A2A agent.

Design:
  - JWKS fetched from Keycloak once and cached in memory with a TTL.
  - On any validation failure the cache is invalidated (handles key rotation).
  - validate_token()  → returns claims dict  or raises AuthError
  - require_role()    → raises AuthError if role missing from claims
  - extract_bearer()  → pulls "Bearer <token>" → "<token>" from header string
"""

import time
import asyncio
import logging
from contextvars import ContextVar
from dataclasses import dataclass, field

import httpx
from jose import jwt, JWTError, ExpiredSignatureError

from shared.config import KEYCLOAK_JWKS_URL, KEYCLOAK_ISSUER

logger = logging.getLogger(__name__)

# ── Context variable: injected by ASGI middleware in every A2A agent ──────────
# Each A2A agent wraps its ASGI app with TokenMiddleware (see base_agent.py).
# The middleware writes the raw token here so any executor can read it with
# current_token.get() without needing to touch HTTP internals.
current_token: ContextVar[str] = ContextVar("current_token", default="")


# ── Custom exception ──────────────────────────────────────────────────────────
@dataclass
class AuthError(Exception):
    status_code: int  # 401 or 403
    detail: str

    def __str__(self):
        return self.detail


# ── JWKS cache ────────────────────────────────────────────────────────────────
@dataclass
class _JWKSCache:
    """Thread-safe async JWKS cache with TTL and force-refresh capability."""
    ttl: int = 3600          # seconds to keep keys before re-fetching
    _data: dict = field(default_factory=dict, repr=False)
    _fetched_at: float = 0.0
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock, repr=False)

    async def get(self, force_refresh: bool = False) -> dict:
        async with self._lock:
            now = time.monotonic()
            if force_refresh or not self._data or (now - self._fetched_at) > self.ttl:
                logger.debug("Fetching JWKS from %s", KEYCLOAK_JWKS_URL)
                async with httpx.AsyncClient() as client:
                    resp = await client.get(KEYCLOAK_JWKS_URL, timeout=10)
                    resp.raise_for_status()
                    self._data = resp.json()
                    self._fetched_at = now
            return self._data

    def invalidate(self):
        self._fetched_at = 0.0


# Module-level singleton cache
_jwks_cache = _JWKSCache()


# ── Core validation ───────────────────────────────────────────────────────────
async def validate_token(token: str) -> dict:
    """
    Decode and verify a Keycloak JWT.

    Returns the claims dict on success.
    Raises AuthError(401) on expired / invalid token.

    On first failure it force-refreshes the JWKS (handles key rotation)
    and retries once before giving up.
    """
    if not token:
        raise AuthError(401, "No token provided")

    for attempt in range(2):
        try:
            jwks = await _jwks_cache.get(force_refresh=(attempt > 0))
            claims = jwt.decode(
                token,
                jwks,
                algorithms=["RS256"],
                issuer=KEYCLOAK_ISSUER,
                options={"verify_aud": False},   # Keycloak puts client-id in azp
            )
            return claims
        except ExpiredSignatureError:
            raise AuthError(401, "Token has expired")
        except JWTError as exc:
            if attempt == 0:
                _jwks_cache.invalidate()
                logger.warning("JWT validation failed (attempt 1), refreshing JWKS: %s", exc)
                continue
            raise AuthError(401, f"Invalid token: {exc}")

    raise AuthError(401, "Token validation failed after JWKS refresh")


def require_role(claims: dict, role: str) -> None:
    """
    Assert that `role` appears in realm_access.roles.
    Raises AuthError(403) if not present.
    """
    realm_roles: list[str] = claims.get("realm_access", {}).get("roles", [])
    if role not in realm_roles:
        raise AuthError(
            403,
            f"Forbidden: role '{role}' is required to use this agent. "
            f"Your roles: {realm_roles or ['(none)']}",
        )


def extract_bearer(authorization_header: str) -> str:
    """
    'Bearer eyJhb...' → 'eyJhb...'
    Returns empty string if header is missing or malformed.
    """
    if authorization_header and authorization_header.startswith("Bearer "):
        return authorization_header[7:].strip()
    return ""


# ── ASGI middleware ───────────────────────────────────────────────────────────
class TokenMiddleware:
    """
    Pure ASGI middleware — wraps any ASGI app (including A2AStarletteApplication).

    For every incoming HTTP request it:
      1. Reads the Authorization header from the ASGI scope.
      2. Stores the raw token in the `current_token` ContextVar.

    This makes the token available to AgentExecutor.execute() via:
        token = current_token.get()
    without touching the A2A protocol layer at all.
    """

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http":
            headers = {
                k.lower(): v
                for k, v in scope.get("headers", [])
            }
            raw_auth = headers.get(b"authorization", b"").decode("utf-8", errors="ignore")
            token = extract_bearer(raw_auth)
            current_token.set(token)

        await self.app(scope, receive, send)
